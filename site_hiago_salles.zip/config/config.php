<?php
$hotmart_token = getenv('HOTMART_TOKEN'); 
?>
<?php
// Copie para config.php e preencha com seus dados reais.
// NÃO comite config.php no repositório.

return [
    'hotmart_link' => 'https://go.hotmart.com/SEU_LINK_HOTMART',
    'ebook_link'   => 'https://seudominio.com/brindes/seu-ebook.pdf',
    'site_name'    => 'Covil do Pai Hiago',
    'admin_email'  => 'seu@email.com'
];
