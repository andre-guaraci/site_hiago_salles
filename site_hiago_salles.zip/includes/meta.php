<!-- Open Graph / Social -->
<meta property="og:title" content="Covil do Pai Hiago – Aprenda Quimbanda de Verdade">
<meta property="og:description" content="Curso e comunidade com lives exclusivas todas as quintas às 19h.">
<meta property="og:image" content="/assets/img/og-image.jpg">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/png" href="/assets/img/favicon.png">
