<?php
//sobre.php
?>

<section class="container section section--about">
  <div class="container about__inner">
    <div class="about_content">
        <h2>Sobre o Covil do Pai Hiago</h2>
        <p>
        O <strong>Covil do Pai Hiago</strong> é um espaço sagrado de aprendizado sobre a Quimbanda real — sem máscaras,
        sem invenções. Aqui, você aprende com base em fundamentos tradicionais, estudos e prática espiritual guiada.
        </p>
        <p>
        Além dos conteúdos em vídeo e apostilas digitais, temos <strong>lives exclusivas todas as quintas às 19h</strong>
        para os membros do Covil. O conhecimento é contínuo — novos conteúdos são adicionados regularmente.
        </p> 
    </div>   
  </div>
</section>