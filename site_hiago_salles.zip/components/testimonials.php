<?php
require_once __DIR__ . '/../helpers/utils.php';
include_once __DIR__ . '/../includes/header.php';
?>

<section class="section container depoimentos">
  <h2>Iniciados que já transformaram suas jornadas</h2>
  <p>Depoimentos reais de quem se conectou com o Covil do Pai Hiago e vive essa experiência espiritual.</p>

  <div class="swiper depoimentos-swiper">
    <div class="swiper-wrapper">

      <!-- Depoimento 1 -->
      <div class="swiper-slide depoimento-item">
        <blockquote>
          “O curso do Covil transformou minha visão sobre a Quimbanda. A cada aula, senti uma conexão mais profunda com meus Exus.”
        </blockquote>
        <div class="autor-area">
          <img src="/assets/img/depoimentos/mariana-thumb.jpg" alt="Mariana Lopes" class="autor-foto">
          <div>
            <span class="autor">Mariana Lopes</span>
            <span class="local">– Salvador/BA</span>
          </div>
        </div>
        <button class="ver-print" data-img="/assets/img/depoimentos/mariana.jpg">Ver print</button>
      </div>

      <!-- Depoimento 2 -->
      <div class="swiper-slide depoimento-item">
        <blockquote>
          “Eu já tinha medo de começar, mas encontrei acolhimento e fundamento. Gratidão ao Pai Hiago e à equipe do Covil!”
        </blockquote>
        <div class="autor-area">
          <img src="/assets/img/depoimentos/rafael-thumb.jpg" alt="Rafael Almeida" class="autor-foto">
          <div>
            <span class="autor">Rafael Almeida</span>
            <span class="local">– Campinas/SP</span>
          </div>
        </div>
        <button class="ver-print" data-img="/assets/img/depoimentos/rafael.jpg">Ver print</button>
      </div>

      <!-- Depoimento 3 -->
      <div class="swiper-slide depoimento-item">
        <blockquote>
          “Achei que fosse só mais um curso… mas é uma verdadeira vivência espiritual. Me sinto parte de algo sagrado.”
        </blockquote>
        <div class="autor-area">
          <img src="/assets/img/depoimentos/luana-thumb.jpg" alt="Luana Silva" class="autor-foto">
          <div>
            <span class="autor">Luana Silva</span>
            <span class="local">– Rio de Janeiro/RJ</span>
          </div>
        </div>
        <button class="ver-print" data-img="/assets/img/depoimentos/luana.jpg">Ver print</button>
      </div>

        <!-- Depoimento 4 -->
      <div class="swiper-slide depoimento-item">
        <blockquote>
          “Achei que fosse só mais um curso… mas é uma verdadeira vivência espiritual. Me sinto parte de algo sagrado.”
        </blockquote>
        <div class="autor-area">
          <img src="/assets/img/depoimentos/luana-thumb.jpg" alt="Luana Silva" class="autor-foto">
          <div>
            <span class="autor">Luana Silva2</span>
            <span class="local">– Rio de Janeiro/RJ2</span>
          </div>
        </div>
        <button class="ver-print" data-img="/assets/img/depoimentos/luana.jpg">Ver print</button>
      </div>


    </div>

    <div class="swiper-pagination"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
  </div>

  <!-- Modal de visualização -->
  <div id="printModal" class="print-modal">
    <div class="print-modal-content">
      <span class="close-modal">&times;</span>
      <img id="printModalImg" src="" alt="Print do depoimento">
    </div>
  </div>
</section>
